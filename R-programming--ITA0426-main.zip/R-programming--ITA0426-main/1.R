a = c(1,2,3,4,5,6)
a
print(paste("Type: ", class(a)))

b = c("Gokul","Raghul","Dhanush")
b
print(paste("Type: ", class(b)))

c = c(TRUE, FALSE, TRUE, FALSE)
c
print(paste("Type: ", class(c)))
