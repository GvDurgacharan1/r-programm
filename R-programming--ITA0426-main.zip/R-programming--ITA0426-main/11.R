data <- read.csv("students_copy.csv")
print("Contents of the CSV file:")
print(data)
