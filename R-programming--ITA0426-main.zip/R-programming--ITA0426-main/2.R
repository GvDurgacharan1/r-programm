
# Create a 5x4 matrix
a <- matrix(1:20, nrow = 5, ncol = 4)
print(a)

# Create a 3x3 matrix
b <- matrix(1:9, nrow = 3, ncol = 3)
print(b)

# Create a 2x2 matrix
c <- matrix(1:4, nrow = 2, ncol = 2)
print(c)
