a=1:8
b=array(a, dim=c(2,2,2))
print(b)
print(b[2,1,2])