rm(c)
plot(1, type = "n",
     xlim = c(0,10),
     ylim = c(0,100),
     xlab = "x axis",
     ylab = "y axis")